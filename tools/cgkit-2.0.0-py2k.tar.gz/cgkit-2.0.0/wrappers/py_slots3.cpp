/*
 Slots - part 3
 */

#include "py_slot.h"


void class_Slots3()
{
  SLOT("Mat3Slot",mat3d);
  SLOT("Mat4Slot",mat4d);
}
