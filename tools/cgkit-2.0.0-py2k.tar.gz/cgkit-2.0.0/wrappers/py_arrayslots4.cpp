/*
 ArraySlots - part 4
 */

#include "py_slot.h"

void class_ArraySlots4()
{
  ARRAYSLOT("BoolArraySlot",bool);
  ARRAYSLOT("StrArraySlot",string);
  //  ARRAYSLOT("PyArraySlot",object);
}
