/*
 Mat3ArraySlot
 */

#include "py_slot.h"

void class_Mat3ArraySlot()
{
  // Compiling Mat3ArraySlot with stlport results in an "Internal Compiler
  // Error" on Windows...?!? (whereas Mat4ArraySlot compiles fine!?!)

  //  ARRAYSLOT("Mat3ArraySlot",mat3d);
}
