/*
 Mat4ArraySlot
 */

#include "py_slot.h"

void class_Mat4ArraySlot()
{
  ARRAYSLOT("Mat4ArraySlot",mat4d);
}
